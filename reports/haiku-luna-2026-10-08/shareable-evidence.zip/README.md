# Sanitized benchmark evidence

Local completed-matrix report and unpublished Unbenchmark draft. Read report.md for denominators, timing/identity limits and vendor-claim scope. results.csv has 192 primary arm rows. The original wrong-effort physical attempt is retained in the manifest and physical summaries. No raw private native transcript or host context is included.

Only the explicit archive allowlist is packaged. Input hashes and audit hashes support provenance but do not independently reproduce private evidence review. No model call, grading, live aggregation, UI or publication is performed by this builder.
